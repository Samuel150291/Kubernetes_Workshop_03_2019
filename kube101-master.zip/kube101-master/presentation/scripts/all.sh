#!/bin/bash
set -e

./lab1-1.sh
./lab1-2.sh
./lab1-3.sh
./lab2-1.sh
./lab2-2.sh

./clean.sh
